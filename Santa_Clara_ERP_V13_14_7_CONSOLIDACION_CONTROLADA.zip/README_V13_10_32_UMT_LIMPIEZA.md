# Santa Clara ERP V13.10.32 — UMT + Limpieza

Base: V13.10.31 aportada por el usuario.

## UMT
- Stock individual por bolsa/unidad de hemocomponentes.
- Código interno UMT-000001.
- Grupo ABO y Rh, componente, procedencia, ingreso, extracción y vencimiento.
- Estados: disponible, reservado, utilizado, canjeado y baja.
- Alertas visuales por vencimiento y días configurables por hemocomponente.
- Registro de canjes e historial de movimientos.
- Bloqueo de reserva/utilización de unidades vencidas.

## Limpieza / Control interno
- Maestro independiente de productos de limpieza.
- Entradas y salidas por sector, responsable y referencia.
- Stock físico calculado desde movimientos.
- Control de stock mínimo.
- No usa stock_mov, no genera inventario contable, IVA, costo de ventas ni asientos.

## Seguridad
- Módulos independientes UMT y LIMPIEZA con permisos.
- SIFEN no fue modificado.
- Migraciones son aditivas y no eliminan datos existentes.
