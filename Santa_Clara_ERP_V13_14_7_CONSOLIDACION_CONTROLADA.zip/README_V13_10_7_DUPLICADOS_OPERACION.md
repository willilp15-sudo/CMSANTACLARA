# Santa Clara ERP V13.10.7 — Control de duplicados + operación SIFEN

- Bloquea nuevos clientes/pacientes duplicados por C.I./RUC normalizado.
- Bloquea nuevos proveedores duplicados por RUC/documento normalizado.
- También controla duplicados al editar registros existentes.
- No elimina ni fusiona automáticamente registros históricos.
- Automatiza iTiOpe en casos inequívocos: extranjero B2F, no contribuyente B2C, persona jurídica contribuyente B2B.
- Para persona física con RUC conserva B2B/B2C según la naturaleza concreta de la operación; no se fuerza una clasificación incorrecta solo por poseer RUC.
- No modifica el motor de emisión, firma, QR, transmisión, consulta ni cancelación SIFEN.
