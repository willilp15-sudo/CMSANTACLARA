# Santa Clara ERP V13.9.144 — Cancelación SIFEN

- Corrige el botón Anular para facturas DTE aprobadas.
- Genera Evento Emisor tipo 1 (Cancelación) V150 con CDC y motivo.
- Firma digitalmente rEve y transmite por WS Eventos sincrónico.
- Sólo marca la factura CANCELADA cuando SIFEN responde código 0600.
- Si SIFEN rechaza el evento, la factura permanece APROBADA y se guarda la respuesta.
- No reutiliza el flujo de recepción DE ni envío por lote para cancelar.
- Conserva sin cambios el algoritmo QR/IdCSC de V13.9.143.
