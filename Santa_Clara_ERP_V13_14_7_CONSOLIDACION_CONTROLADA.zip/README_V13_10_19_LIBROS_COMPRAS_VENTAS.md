# V13.10.19 - Importación Libro Compras y Libro Ventas
Base: V13.10.18 CONTRATOS RRHH aportada por el usuario.

Cambios:
- Contabilidad > Importar/Exportar muestra tarjetas Libro Compras y Libro Ventas.
- Plantillas Excel para ambos libros.
- Importación mediante el motor existente de transacciones, sin retransmitir SIFEN.
- Libro IVA resumido con cabeceras previas se reconoce para Compras y Ventas.
- Reportes resumidos se convierten en líneas de servicio contable y no inventan stock físico.
- Exportación Excel/CSV enlazada a los libros IVA existentes.

Archivos modificados: app.py, templates/accounting_exchange.html.
