# Santa Clara ERP V13.9.143 — SIFEN QR / Documento Electrónico

Cambios sobre V13.9.142:
- IdCSC se valida como identificador numérico de 1 a 4 dígitos y se normaliza a 4 posiciones (ej.: 1 -> 0001).
- Se impide usar accidentalmente el RUC o el CSC secreto como IdCSC.
- CSC V150 validado a 32 caracteres.
- El CSC ya no se vuelve a insertar como value del campo password en el HTML. Dejar el campo vacío conserva el CSC instalado.
- Generación cHashQR: cadena V150 + CSC secreto -> SHA-256 hexadecimal.
- Prueba contra el ejemplo oficial del Manual Técnico V150: hash coincidente.
- Diagnóstico SIFEN reforzado para IdCSC/CSC.
- Sección Documento Electrónico ampliada con servicios: Consulta RUC, Consulta DE/CDC, Consulta Lote, envío sync, envío por lote, eventos y URL QR.
- Endpoint interno consulta_ruc agregado al mapa SIFEN.

Antes de producción:
1. Configurar el IdCSC real. Si el sistema autorizado muestra ID CSC 1, ingresar 1; el ERP normaliza el QR a 0001.
2. Instalar/configurar el CSC secreto correspondiente (32 caracteres).
3. Ejecutar diagnóstico y autoprueba XML V150.
4. Probar en TEST cuando corresponda y revisar respuesta SIFEN.
5. No considerar un DE como DTE hasta que SIFEN lo apruebe.
