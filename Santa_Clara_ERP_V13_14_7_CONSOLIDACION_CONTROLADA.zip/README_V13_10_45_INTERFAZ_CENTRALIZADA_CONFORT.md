# Santa Clara ERP V13.10.45 — Interfaz centralizada y Confort

Base: V13.10.44 QR Documental + Reinicio, suministrada por el usuario.

## Cambios
- Navegación superior reorganizada y centralizada.
- Nuevo acceso global a Maestros, agrupado en Personas, Productos/Existencias y Administrativos.
- Centro de Informes visible desde la navegación principal.
- Dashboard reorganizado en Atención y operación, Gestión administrativa, y Control/configuración.
- Tema Confort predeterminado de menor fatiga visual.
- Selector Confort / Claro / Oscuro, persistente por navegador.
- Unificación visual de tarjetas, formularios, tablas, encabezados y menús.
- Mejoras responsive para escritorio, tablet y móvil.

## Integridad funcional
- app.py no fue modificado en esta versión visual.
- No se modificó lógica SIFEN, CDC, XML, firma, QR fiscal, emisión ni cancelación.
- Se conservan QR documental, reinicio controlado de base y Asistencia Móvil de la base V13.10.44.

## Archivos modificados
- templates/base.html
- templates/dashboard.html
- static/app.css
