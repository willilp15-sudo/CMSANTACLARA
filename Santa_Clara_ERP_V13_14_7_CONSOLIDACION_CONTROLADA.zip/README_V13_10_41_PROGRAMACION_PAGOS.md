# Santa Clara ERP V13.10.41 — Programación de Pagos

Base: V13.10.39 suministrada por el usuario.

- Nuevo módulo Tesorería > Programación de Pagos.
- Selección de proveedor y una o varias facturas CxP.
- Pago total o parcial por factura.
- Cuenta bancaria/caja de salida y saldo visible.
- Prioridad y fecha programada.
- Estados PROGRAMADO, AUTORIZADO, PAGADO y CANCELADO.
- Programar/autorizar no afecta fondos ni CxP.
- Ejecutar pago genera pago a proveedor, movimiento de Tesorería, asiento contable y reduce CxP.
- Control de sobreprogramación por factura.
- Trazabilidad de usuarios y fechas.
- SIFEN no fue modificado.
