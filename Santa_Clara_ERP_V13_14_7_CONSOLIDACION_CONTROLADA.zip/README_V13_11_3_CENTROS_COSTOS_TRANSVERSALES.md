# Santa Clara ERP V13.11.3 — Centros de Costos Transversales

- Centro de costo incorporado a Compras y Ventas con selección manual.
- Las operaciones clínicas conservan asignación automática por área (Recepción, Consultorios, Urgencias, Internación, Quirófano, Farmacia, Laboratorio, Ambulancia).
- La selección manual prevalece sobre la automática cuando corresponde.
- Centro de costo incorporado al legajo del funcionario y a novedades de RR.HH.
- Anticipos/préstamos heredan el centro del funcionario o el seleccionado y lo llevan al asiento.
- Liquidaciones de RR.HH. conservan el centro del funcionario para análisis posterior.
- El centro de costo se conserva en Compras, Ventas, RR.HH., movimientos y asiento_det.
- Corregido el informe por centro de costo para respetar realmente el rango de fechas.
- El informe por centro de costo tiene Descargar PDF e Imprimir usando exactamente el mismo PDF institucional.
- Se mantiene el criterio V13.11.2 del Centro de Informes: impresión y descarga PDF comparten el mismo formato.
- No se elimina ni reemplaza la base de datos; las columnas nuevas se agregan por migración.
