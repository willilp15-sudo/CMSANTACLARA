# Santa Clara ERP V13.10.9 — Roles y permisos predeterminados

Base: V13.10.8 Ingreso de Pacientes Unificado.

## Cambios
- Roles estándar con perfiles iniciales de permisos.
- Se conservan las personalizaciones existentes: el arranque NO pisa permisos ya configurados.
- Los roles estándar faltantes se crean automáticamente.
- Si un rol estándar existe pero no tiene permisos, recibe su perfil inicial.
- Botón **Restaurar predeterminados** por rol estándar, con confirmación.
- Los permisos pueden seguir modificándose manualmente después.
- Se mantiene multirrol: los permisos efectivos de un usuario son la suma de sus roles.
- Se agrega el rol `INGRESO_PACIENTES`, manteniendo `ADMISION` por compatibilidad con usuarios existentes.

## Perfiles incluidos
ADMINISTRADOR, RECEPCION, INGRESO_PACIENTES, ADMISION (compatibilidad), MEDICO, ENFERMERIA, URGENCIAS, QUIROFANO, FARMACIA, VENTAS_CAJA, COMPRAS, CONTABILIDAD, LABORATORIO e INFORMES.

## Archivos modificados
- app.py
- templates/admin_roles.html

No se modificó el motor SIFEN, emisión FE/NCE/NDE, firma, QR, cancelación ni la base de datos fiscal.
