# Santa Clara ERP V13.10.30 — Contabilidad Fiscal Paraguay
Base real: V13.10.27 subida por el usuario. Integra además las mejoras pendientes de V13.10.28 y RG90 de V13.10.29.

## Incorporado
- Centro Contable-Fiscal Paraguay.
- RG90/Marangatu Compras y Ventas no electrónicas con validación y exportación ZIP/CSV/TXT.
- Retenciones recibidas/practicadas: registro, importación flexible XLSX/CSV/TXT desde reportes Marangatu, anulación y exportación CSV de control.
- Papel de trabajo IVA mensual (10%, 5%, exentas, débito/crédito fiscal).
- Conciliación Compras/Ventas vs asientos contables.
- Obligaciones fiscales configurables de control.
- Apoyo a notas de EE.FF. sobre utilidades/resultados.
- Edición/desactivación segura de depósitos y anulación de transferencias con reversión (pendiente de V13.10.28).

## Seguridad
No modifica el núcleo SIFEN de emisión/firma/CDC/QR/cancelación. No borra ni reemplaza la base existente. Las migraciones son aditivas.

## Importante
Los papeles de trabajo y archivos auxiliares no sustituyen la declaración jurada ni la revisión profesional. La importación de retenciones es flexible porque los reportes descargados pueden variar; antes de contabilizar se recomienda validar contra el archivo real de Marangatu.
