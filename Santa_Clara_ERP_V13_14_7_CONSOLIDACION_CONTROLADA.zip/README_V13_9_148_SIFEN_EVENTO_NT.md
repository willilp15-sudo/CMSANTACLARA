# Santa Clara ERP V13.9.148 — Evento SIFEN conforme Nota Técnica

Corrección puntual del evento de cancelación:
- elimina dTiGDE del XML del evento conforme Nota Técnica SIFEN (gGroupTiEvt usa xs:choice);
- usa identificador de evento de 10 dígitos también como dId de control;
- conserva estructura rEnviEventoDe/dEvReg/gGroupGesEve/rGesEve/rEve/Signature;
- no modifica emisión FE, QR, CSC, IdCSC, base de datos ni configuración.
