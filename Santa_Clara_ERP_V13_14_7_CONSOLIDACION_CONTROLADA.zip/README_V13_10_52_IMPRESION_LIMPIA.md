# Santa Clara ERP V13.10.52 - Impresión limpia

Base: V13.10.51.

Cambios:
- Recibos: impresión exclusiva del documento, sin barra/menu/panel del ERP.
- Facturas HTML: impresión exclusiva del documento.
- A4 con márgenes reducidos y compactación del recibo para evitar segunda hoja cuando el contenido cabe.
- No modifica app.py ni SIFEN.

Archivos modificados:
- static/app.css
- templates/receipt.html
- templates/invoice_sale.html
