# Santa Clara ERP V13.10.3 — Punto 001-001 Producción

- Base: V13.10.2.
- No modifica el motor de emisión FE, firma XMLDSig, QR, cancelación, NCE/NDE ni transporte SIFEN.
- Corrige el bloqueo que impedía actualizar el timbrado de un punto que ya tenía documentos asociados.
- Conserva bloqueados establecimiento, punto y correlativo cuando existe historial.
- Migración idempotente: si 001-001 tiene como timbrado el RUC (error histórico) o está vacío, toma el timbrado vigente de sifen_config y habilita FE/NCE/NDE, autorizado DNIT y activo.
- No modifica documentos históricos, XML, CDC, protocolos ni correlativos.
