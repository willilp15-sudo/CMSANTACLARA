# Santa Clara ERP V13.10.21 — Gasparini CSV Ventas

Base: V13.10.20 suministrada por el usuario.

## Cambio
- Importación directa del Libro IVA Ventas de Gasparini en CSV CP1252 sin encabezados (16 columnas).
- Detecta factura, fecha, cliente, RUC/DV, base/IVA 10%, base/IVA 5%, exentas, total y timbrado.
- Los RUC compuestos solamente por ceros se tratan como consumidor sin RUC y se relacionan por nombre, evitando fusionar clientes distintos.
- La importación es histórica/tributaria: no transmite a SIFEN, no genera CDC y usa líneas SERVICIO sin stock.
- Conserva exactamente los totales tributarios informados por Gasparini.
- Se corrigió además la conservación de totales Gasparini para no sumar repetidamente los mismos totales cuando una factura genera más de una línea sintética.

## Validación con archivo real
VENTAS 2026.csv: 5.795 filas, 16 columnas, CP1252. Las 5.795 filas cumplen patrón de factura/fecha y conciliación total = base10 + IVA10 + base5 + IVA5 + exentas (tolerancia Gs. 1).
