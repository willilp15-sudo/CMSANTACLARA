# Santa Clara ERP V13.10.0 — Reestructuración Operativa

Base: V13.9.149 estable.

## Alcance
- Reorganización del menú por procesos del sanatorio.
- Ventas concentra recepción, caja, facturación, clientes, documentos y seguros.
- Atención concentra agenda, consultorio, historia clínica e internación.
- SIFEN pasa a módulo visible propio sin modificar su motor.
- Tesorería agrupa finanzas y bancos.
- Nuevo Centro de Operaciones con accesos rápidos y flujos principales.
- No se eliminaron rutas ni módulos existentes.
- No se modificó app.py ni el núcleo SIFEN estable de V13.9.149.

## Archivos modificados
- templates/base.html
- templates/dashboard.html
- static/app.css
