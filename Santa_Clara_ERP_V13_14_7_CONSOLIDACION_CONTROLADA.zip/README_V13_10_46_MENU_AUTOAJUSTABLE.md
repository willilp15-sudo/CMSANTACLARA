# Santa Clara ERP V13.10.46 — Menú superior autoajustable

Base: V13.10.45 INTERFAZ CENTRALIZADA CONFORT.

## Cambio
- Corrige la barra superior que podía quedar cortada horizontalmente.
- Elimina el desplazamiento horizontal del menú.
- Compacta progresivamente tipografía, logo y espacios según el ancho.
- Cuando una sola fila no es físicamente suficiente, permite una segunda fila ordenada en vez de ocultar módulos.
- Conserva todos los menús y permisos.
- No modifica app.py, base de datos, rutas, SIFEN ni lógica operativa.

## Actualización desde V13.10.45
Reemplazar solamente:
- static/app.css
