# Santa Clara ERP V13.10.5 — Consulta RUC y correo de factura electrónica

- Consulta automática del WS oficial Consulta RUC SIFEN V150 usando el certificado digital ya instalado.
- Al ingresar C.I./RUC en Clientes, intenta identificar si existe como RUC y completar razón social/nombre, DV y condición de contribuyente.
- Si no se encuentra RUC, permite continuar como no contribuyente con C.I. sin inventar datos.
- Agrega correo específico para factura electrónica y preferencia de envío.
- Agrega botón "Enviar por correo" en la factura aprobada: adjunta KuDE PDF y, si está disponible, el XML DTE firmado/aprobado ya guardado. No regenera ni retransmite el DTE.
- SMTP por variables de entorno: SMTP_HOST, SMTP_PORT (587), SMTP_USER, SMTP_PASSWORD, SMTP_FROM, SMTP_TLS (1), SMTP_SSL (0).
- No modifica generación CDC, XML, firma, QR, transmisión, aprobación, cancelación, NCE/NDE ni correlativos SIFEN.
