# Santa Clara ERP V13.13.0 — Mapeo integral e interfaz simplificada

## Criterio
Se preservan las rutas y datos históricos, pero se eliminan del menú principal los accesos repetidos. El usuario entra por un único botón de macroproceso y las funciones técnicas quedan dentro del flujo.

## Macroprocesos visibles
1. Atención: Agenda/Ingreso → Consulta/Urgencia → Internación → Consumos → Alta/Facturación.
2. Ventas: Cuenta/servicio → Factura → SIFEN → Cobro/Recibo → Contabilidad.
3. Compras: Proveedor → Compra → Stock/Costo → CxP → Pago → Contabilidad/Fiscal.
4. Stock: Compra → Depósito → Transferencia → Solicitud → Entrega/Consumo → Costo/Centro de costo.
5. Tesorería: CxC/CxP → Cobro/Pago → Caja/Banco → Conciliación → Contabilidad.
6. RR.HH.: Funcionario → Asistencia/Novedad → Liquidación → Pago → Contabilidad/Centro de costo.
7. Contabilidad: Operaciones → Asientos → Diario/Mayor → Balances → IVA/RG90 → Cierre/Estados.
8. Informes: un único centro de salida para información operativa, administrativa y contable.
9. Maestros: datos base compartidos; no deben existir maestros paralelos por módulo.
10. Administración: usuarios/permisos, configuración, SIFEN, auditoría y backups.

## Duplicidades retiradas del menú principal
- Recepción, Caja, Cobros y Facturación dejan de competir como botones principales: se accede por Ventas.
- Agenda, Consultorio, Historia, Admisión, Enfermería y Laboratorio se agrupan bajo Atención.
- CxP y Pagos a Proveedores pertenecen al flujo Compras/Tesorería, no como procesos aislados.
- CxC y Cobros pertenecen al flujo Ventas/Tesorería.
- Bancos, depósitos, transferencias, POS, conciliación y tipo de cambio quedan bajo Tesorería.
- Plan, Diario, Mayor, balances, fiscal y centros de costo quedan bajo Contabilidad.
- Funcionarios, asistencia, novedades, liquidación y pago quedan bajo RR.HH.
- Configuraciones técnicas salen del trabajo diario y quedan bajo Administración.

## Regla de trazabilidad
Ninguna operación debe requerir recarga manual para llegar a stock/costo, tesorería, contabilidad, centro de costo, fiscal o informes. Las rutas históricas se conservan para compatibilidad y trazabilidad; ocultarlas del menú no borra información ni rompe referencias.
