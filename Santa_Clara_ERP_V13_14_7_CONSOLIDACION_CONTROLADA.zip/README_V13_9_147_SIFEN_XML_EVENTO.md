# V13.9.147 - SIFEN Evento Cancelación XML V150

Corrección específica del error SIFEN 0160 (XML mal formado) en el Evento de Cancelación.

- Construye el SOAP completo antes de firmar.
- Estructura: rEnviEventoDe/dEvReg/gGroupGesEve/rGesEve/rEve.
- Agrega xsi:schemaLocation de siRecepEvento_v150.xsd.
- Firma rEve por Id dentro de su contexto final y deja Signature como hermano dentro de rGesEve.
- Canonicalización XML 1.0 conforme al ejemplo técnico V150.
- Mantiene dTiGDE=1, CDC de 44 dígitos y motivo 5-500.
- No modifica emisión DE, QR, CSC ni IdCSC.
