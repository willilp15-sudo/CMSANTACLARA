# Santa Clara ERP V13.10.53 — Formato único de recibos

Base: V13.10.52 proporcionada por el usuario.

## Cambio
- El botón **Imprimir recibo** ya no ejecuta `window.print()` sobre la plantilla HTML.
- Tanto **Imprimir recibo** como **PDF listo para imprimir** abren `/recibos/<id>/pdf`.
- De esta forma existe un único generador oficial del recibo y ambos resultados son idénticos.
- No se modificó `app.py`, base de datos ni SIFEN.

## Actualización desde V13.10.52
Reemplazar únicamente `templates/receipt.html`.
