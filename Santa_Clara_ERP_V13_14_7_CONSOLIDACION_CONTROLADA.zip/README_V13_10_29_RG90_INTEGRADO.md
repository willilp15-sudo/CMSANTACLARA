# Santa Clara ERP V13.10.29
Base: V13.10.27. Integra funciones pendientes V13.10.28 y módulo RG 90 / Marangatu.

## RG 90
- Centro visible en Contabilidad > RG 90 / Marangatu.
- Compras y Ventas no electrónicas separadas.
- Filtro mensual, vista previa y validación de datos obligatorios.
- CSV UTF-8, TXT UTF-8 tabulado y ZIP con nomenclatura RUC_REG_MMAAAA_XXXXX.
- Máximo 5.000 registros por archivo.
- Ventas aprobadas por SIFEN se excluyen de la exportación manual.

## Stock pendiente de V13.10.28
- Editar/eliminar/desactivar depósitos con protección de historial.
- Editar responsables/observación de transferencias.
- Anular transferencias confirmadas con reversión controlada de stock.

No modifica el núcleo SIFEN de emisión/cancelación.
