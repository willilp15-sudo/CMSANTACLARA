# V13.10.16 — Cajas por usuario y Recepción doble

- Administración > Usuarios y roles permite asignar hasta dos cajas por usuario.
- Validación de máximo 2 cajas en backend.
- Se crean, si faltan, Caja Recepción 1 y Caja Recepción 2.
- Ambas se vinculan inicialmente al punto 001-001 cuando existe y todavía no tienen vínculo.
- El correlativo continúa perteneciendo al punto SIFEN; ambas cajas comparten la secuencia 001-001.
- Cada usuario solo puede abrir una caja a la vez y cada caja solo puede estar abierta por un usuario a la vez.
- No se modifica el motor SIFEN, XML, firma, QR, CDC, NCE/NDE ni cancelación.
