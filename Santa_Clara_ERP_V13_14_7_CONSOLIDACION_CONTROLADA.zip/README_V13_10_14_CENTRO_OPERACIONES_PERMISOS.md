# V13.10.14 — Centro de Operaciones por permisos

- El Centro de Operaciones muestra únicamente tarjetas correspondientes a módulos habilitados para el usuario.
- Los permisos se resuelven con `has_perm`, igual que el menú principal.
- Administrador conserva acceso completo por la regla SUPERADMIN existente.
- Se eliminó por completo el bloque visual "Flujos principales" del dashboard.
- No se modificó el núcleo de FE/NCE/NDE, XML, firma, QR, SIFEN, correlatividad, cancelación ni lógica de stock de V13.10.13.
