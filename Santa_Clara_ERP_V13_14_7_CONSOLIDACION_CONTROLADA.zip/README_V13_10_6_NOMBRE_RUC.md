# Santa Clara ERP V13.10.6 — Nombre/Razón Social desde Consulta RUC SIFEN

Corrección puntual sobre V13.10.5.

- Lee `dRazCons`, campo oficial de razón social en `ContenedorRUC_v150.xsd`.
- Completa automáticamente Nombre / Razón social cuando SIFEN responde 0502.
- Si el usuario ingresa RUC con DV (ej. 4909510-2), consulta solamente el RUC base (4909510).
- Conserva cálculo/normalización de DV existente.
- Lee estado desde `dDesEstCons` / `dCodEstCons`.
- No modifica emisión FE, CDC, XML, firma, QR, transmisión, cancelación, NCE/NDE ni monitor.
