# Santa Clara ERP V13.10.4 — Facturación a terceros

Base: V13.10.3.

## Objetivo
Separar la persona atendida (paciente) del receptor fiscal de la factura.

## Implementado
- Consultas/procedimientos de consultorio: selector "Facturar a".
- Urgencias, internación y quirófano: selector "Facturar a" en cuenta del paciente y Caja Central.
- Diferencias no cubiertas por seguros: receptor fiscal seleccionable.
- La factura/KuDE muestra "Facturado para" y "Paciente" por separado.
- Informe de Ventas y Facturación muestra Paciente y Facturado para.
- La tabla ventas incorpora paciente_id y facturado_a_tercero_id mediante migración idempotente.
- SIFEN continúa tomando el receptor desde ventas.cliente_id; no se modificó el motor de XML, firma, QR, transmisión, consulta ni cancelación.

## Actualización
Reemplazar app.py y las plantillas modificadas. No reemplazar la base de datos ni /var/data.
