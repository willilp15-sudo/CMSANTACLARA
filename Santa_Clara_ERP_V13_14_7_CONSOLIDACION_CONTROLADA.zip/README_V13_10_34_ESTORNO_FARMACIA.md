# Santa Clara ERP V13.10.34 — Estorno / devolución de Farmacia

Base: V13.10.33 proporcionada por el usuario.

## Cambios
- Farmacia puede estornar total o parcialmente artículos ya entregados desde solicitudes de Enfermería.
- Nueva columna aditiva `cantidad_devuelta` en `solicitud_farmacia_items`.
- El estorno valida que no se devuelva más de lo entregado pendiente.
- Reintegra la cantidad a `productos.stock`.
- Registra `stock_mov` tipo `ENTRADA_ESTORNO`, origen `ESTORNO_FARMACIA`.
- Mantiene el cargo original y agrega una línea negativa `ESTORNO` en la cuenta del paciente para auditoría.
- Exige motivo y registra auditoría con usuario/fecha mediante `audit_change`.
- Si la cantidad ya está facturada/cerrada o no hay saldo pendiente suficiente, bloquea el estorno normal.
- Estados nuevos: `DEVOLUCION_PARCIAL` y `DEVUELTA`.

## Archivos modificados
- `app.py`
- `templates/pharmacy_requests.html`

No reemplazar base de datos ni `/var/data`.
