# Santa Clara ERP V13.10.48
Base: V13.10.46 proporcionada por el usuario.

Incluye:
- Código de registro estable para clientes y proveedores.
- Migración aditiva de terceros existentes.
- Importación Gasparini/Excel con Código Tercero cuando esté disponible.
- Corrección de Ver/Imprimir recibos y PDF con relaciones históricas tolerantes y campos nulos.
- Conserva QR documental interno.
- No modifica el motor fiscal SIFEN.

No reemplazar la base SQLite ni /var/data.
