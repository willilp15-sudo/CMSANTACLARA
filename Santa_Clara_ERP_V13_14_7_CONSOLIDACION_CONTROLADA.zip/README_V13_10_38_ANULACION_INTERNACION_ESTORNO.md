# Santa Clara ERP V13.10.38

Corrección puntual de la anulación de internaciones.

- La anulación ya no se bloquea por la mera existencia histórica de solicitudes de Farmacia o notas de Enfermería.
- Farmacia bloquea únicamente cuando queda cantidad entregada sin estornar: cantidad_entregada - cantidad_devuelta > 0.
- La cuenta del paciente bloquea únicamente cuando queda saldo económico no facturado distinto de cero.
- Los movimientos originales y los estornos se conservan para auditoría y trazabilidad.
- Se mantiene el bloqueo de internaciones ya facturadas.
- SIFEN no fue modificado.

Actualización desde V13.10.37: reemplazar únicamente app.py. No reemplazar la base de datos ni /var/data.
