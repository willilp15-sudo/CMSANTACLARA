# Santa Clara ERP V13.10.12
Base acumulativa: V13.10.11.

## Registro de Visaciones
- Filtros por texto, fecha desde/hasta y seguro.
- Exportación PDF respetando exactamente los filtros activos.
- Exportación Excel XLSX respetando exactamente los filtros activos.
- PDF institucional con período y cantidad de registros.
- Excel con fecha, hora, visación, paciente, documento, seguro, médico, origen, observación y auditoría.
- No modifica SIFEN, facturación electrónica, cajas ni correlatividad.
