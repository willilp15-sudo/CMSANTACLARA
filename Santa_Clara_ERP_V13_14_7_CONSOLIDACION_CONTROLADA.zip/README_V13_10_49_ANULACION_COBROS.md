# Santa Clara ERP V13.10.49 — Anulación de Cobros y Recibos

Base: V13.10.48 suministrada por el usuario.

- Permite anular un cobro desde el recibo con permiso FINANZAS/ANULAR.
- Exige motivo y evita doble anulación.
- Conserva el recibo original y lo marca ANULADO.
- Recalcula CxC y cuotas usando únicamente recibos vigentes.
- Registra reversión en Caja/Banco; para efectivo exige caja abierta y registra egreso.
- Genera asiento contable inverso del asiento original, sin borrar contabilidad.
- QR documental existente y nuevos QR del recibo muestran estado ANULADO.
- PDF/impresión muestran RECIBO ANULADO y motivo.
- No modifica SIFEN, CDC, XML, firma ni QR fiscal.

Archivos funcionales modificados: app.py, templates/receipt.html, templates/receipts_list.html.
Migración aditiva automática de recibos_pago: estado, anulado_en, anulado_por, motivo_anulacion, asiento_anulacion_id.
