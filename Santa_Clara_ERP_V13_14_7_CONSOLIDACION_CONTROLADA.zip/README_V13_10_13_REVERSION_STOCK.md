# V13.10.13 — Reversión de stock por NCE/anulación

Versión acumulativa sobre V13.10.12.

- No modifica el motor fiscal SIFEN, XML, CDC, firma, QR, correlativos ni flujo de cancelación 0600.
- NCE: permite marcar Ajuste sin stock o Devolución física.
- Devolución: reintegra únicamente productos que controlan stock; servicios no afectan inventario.
- NCE parcial: reintegra solo la cantidad acreditada.
- Anulación: checkbox explícito para devolución física. El stock se reintegra solo después de una cancelación SIFEN 0600 exitosa, o después de una anulación interna válida.
- Protección anti-duplicado mediante stock_ajustado / stock_revertido_anulacion.
- Cada reintegro registra stock_mov con origen DEVOLUCION_NCE o ANULACION_VENTA.
