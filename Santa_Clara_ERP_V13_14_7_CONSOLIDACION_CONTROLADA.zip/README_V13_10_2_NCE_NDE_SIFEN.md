# Santa Clara ERP V13.10.2 — NCE/NDE SIFEN

Base: V13.10.1. El núcleo FE/cancelación estable no fue sustituido.

Cambios:
- NCE (iTiDE=5) y NDE (iTiDE=6) usan el generador rDE V150 existente.
- NDE usa iMotEmi=8 / Ajuste de precio; NCE usa iMotEmi=1 / Devolución y Ajuste de precios.
- CDC y código de seguridad persistentes para NCE/NDE: los reintentos no regeneran identidad fiscal.
- Firma XMLDSig, QR, validación XSD y envío por lote reutilizan las mismas funciones del núcleo FE.
- Persistencia de lote/protocolo, respuesta SOAP, HTTP, fecha, errores, intentos y fecha de aprobación.
- Consulta de lote para NCE/NDE.
- Monitor masivo admite FE/NCE/NDE y excluye estados finales.
- Preflight bloquea notas sin FE asociada con CDC válido/APROBADO o punto no habilitado.

Actualización desde V13.10.1: reemplazar app.py y templates/sifen_monitor.html. No reemplazar DB, /var/data, certificados, sifen_core ni configuración.
