Santa Clara ERP V13.14.0 — capa visual inspirada en WILTECH SYSTEMS.
Cambios: templates/base.html, templates/dashboard.html, static/app.css.
No se modifica app.py, DB, rutas, SIFEN ni procesos.
Validación: sintaxis Jinja y compilación Python. Realizar pruebas funcionales en staging antes de producción.
