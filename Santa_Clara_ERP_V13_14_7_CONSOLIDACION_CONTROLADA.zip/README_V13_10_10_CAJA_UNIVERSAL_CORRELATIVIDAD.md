# Santa Clara ERP V13.10.10 — Caja universal y correlatividad por punto

Base: V13.10.9 (incluye roles/permisos predeterminados).

## Cambios
- Cualquier caja autorizada puede localizar y estirar cuentas pendientes de Consultorio, Internación/Ingreso, Cirugía/Quirófano, Urgencias y otros cargos hospitalarios disponibles en Caja Central.
- Las cuentas hospitalarias pendientes se muestran aun sin realizar una búsqueda.
- Para facturar una cuenta pendiente debe existir una caja abierta.
- La factura usa exclusivamente el punto de expedición vinculado a la caja abierta.
- El usuario no puede seleccionar manualmente otro punto en el formulario de facturación de cuentas pendientes.
- El próximo número se consume mediante la correlatividad independiente del punto vinculado.
- Administración de Cajas permite vincular/modificar el punto SIFEN de cada caja.
- El vínculo Caja ↔ Punto no se sobrescribe al reiniciar el sistema.
- Se conserva `origen_area` para trazabilidad e informes aunque facture otra caja.
- Incluye íntegramente V13.10.9: perfiles de permisos predeterminados, multirrol y personalización posterior.

## Seguridad
No se modificó el motor SIFEN de generación XML, firma XMLDSig, QR, envío, consulta, cancelación, NCE/NDE ni los CDC históricos.
No reemplazar la base de datos ni `/var/data`.
