# Santa Clara ERP V13.10.33 — Control de Internaciones

Base: V13.10.32 UMT + Limpieza suministrada por el usuario.

## Mejoras
- Búsqueda de internaciones por código interno `INT-000001`, ID, paciente, C.I. y carnet.
- Filtros por tipo y estado.
- Acciones visibles: Editar, Anular y Eliminar.
- Eliminar solo se muestra para registros sin cargos, enfermería, factura ni farmacia; backend además verifica traslados y remisiones.
- Al eliminar o anular una internación válida se libera la cama asignada.
- Anulación exige motivo y queda registrada en auditoría.
- Se bloquea anulación de internaciones facturadas o con movimientos clínicos/stock pendientes de reversión.
- No se modifica el núcleo SIFEN.
