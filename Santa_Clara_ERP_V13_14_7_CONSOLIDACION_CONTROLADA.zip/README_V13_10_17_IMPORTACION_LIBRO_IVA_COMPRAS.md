# V13.10.17 — Importación Libro IVA Compras

Actualización acumulativa sobre V13.10.16.

- Reconoce reportes CSV/XLS con títulos y filtros antes de la cabecera real.
- Detecta la cabecera `N° Factura / N° Timbrado / Fecha / Proveedor / R.U.C. / dv / Total(10%) / IVA / Total(5%) / IVA / Exentas / Total General`.
- Importa cada comprobante como compra del proveedor, conservando timbrado, fecha, RUC+DV y desglose tributario 10%/5%/exento.
- El reporte resumido no contiene productos físicos ni cantidades. Por seguridad se generan líneas contables sintéticas clasificadas como SERVICIO, por lo que no afectan stock incluso si se marca la opción de afectar stock.
- No modifica SIFEN, FE, NCE/NDE, firma, QR, CDC ni cancelaciones.
