# Santa Clara ERP V13.10.22 — Corrección Visaciones y Autorizaciones

Base: V13.10.21 GASPARINI CSV VENTAS.

## Corrección
La consulta del Registro de Visaciones usaba `pacientes.cedula`, pero el esquema real de pacientes utiliza `pacientes.documento`. Esto provocaba HTTP 500 / `sqlite3.OperationalError: no such column: p.cedula` al abrir `/seguros/visaciones`.

Se corrigieron tanto el filtro por documento como la columna `paciente_documento` del reporte para usar `p.documento`.

No se modificó SIFEN, facturación, NCE/NDE, cajas, correlatividad ni la base de datos. No requiere migración.
