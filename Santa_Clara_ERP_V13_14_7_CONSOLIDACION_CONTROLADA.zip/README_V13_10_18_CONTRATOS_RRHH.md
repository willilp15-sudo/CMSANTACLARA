# V13.10.18 — Contratos RR.HH.

- Importación de modelos de contrato en DOCX dentro de RR.HH.
- Variables automáticas de funcionario y empresa.
- Generación de contrato al crear un funcionario o desde su listado.
- Numeración anual automática: 01/2026, 02/2026... y reinicio 01/2027.
- Reserva de secuencia con transacción SQLite `BEGIN IMMEDIATE` para evitar duplicados concurrentes.
- Registro histórico de contratos y descarga DOCX.
- Anulación administrativa sin reutilización del número.
- Modelos y contratos se guardan en el directorio persistente (`/var/data` en Render).
- No modifica SIFEN, FE, NCE/NDE, CDC, firma, QR, cajas ni correlatividad fiscal.
