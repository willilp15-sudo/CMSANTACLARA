# Santa Clara ERP V13.10.43 — Santa Clara Asistencia móvil

Base: V13.10.42 TARIFARIOS SEGUROS.

## Funcionalidad
- PWA instalable en Android/iPhone desde la URL pública del ERP.
- Acceso de funcionario por documento + PIN.
- Habilitación/deshabilitación y cambio de PIN desde RR.HH. > Control de Asistencia.
- Marcaciones: Entrada, Inicio descanso, Fin descanso y Salida.
- Entrada/Salida actualizan la tabla existente `rrhh_asistencias`.
- Auditoría adicional en `rrhh_marcaciones_movil` con fecha, hora, dispositivo e IP.
- Impide duplicar el mismo tipo de marcación del funcionario en el mismo día.
- PIN almacenado mediante hash; no se guarda en texto plano.

## Instalación en celular
1. Publicar esta versión en el mismo servidor/Render del ERP.
2. En RR.HH. > Control de Asistencia, abrir "Configurar acceso móvil".
3. Seleccionar funcionario, asignar PIN de al menos 4 dígitos y habilitar.
4. En el celular abrir `https://SU-DOMINIO/asistencia`.
5. Android/Chrome: menú > Instalar aplicación / Añadir a pantalla principal.
6. iPhone/Safari: Compartir > Añadir a pantalla de inicio.

## Seguridad
No se modificó la lógica de SIFEN. La app móvil solo interactúa con RR.HH./asistencia.
