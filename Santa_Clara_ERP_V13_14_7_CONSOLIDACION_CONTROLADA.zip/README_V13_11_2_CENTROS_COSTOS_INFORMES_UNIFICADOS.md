# Santa Clara ERP V13.11.2

## Centros de costos
- Maestro ampliado: código, nombre, tipo, centro superior, responsable, descripción y estado.
- Centros iniciales: Administración, Recepción, Consultorios, Urgencias, Internación, Quirófano, Farmacia, Laboratorio, Diagnóstico/Rayos X, Ambulancia, Mantenimiento y RR.HH.
- `asiento_det` incorpora `centro_costo_id`.
- Los nuevos asientos generados por procesos ERP reciben centro de costo automático según su origen.
- Informe por centro de costo disponible desde Contabilidad.
- No se altera el histórico contable existente. Los asientos anteriores a esta versión no reciben imputaciones inventadas automáticamente.

## Centro de Informes
- Descargar PDF e Imprimir usan el mismo generador PDF y, por tanto, el mismo formato institucional.
- Imprimir abre el mismo PDF en el navegador para usar la impresión del visor.
- Excel y CSV continúan disponibles como formatos de datos.
