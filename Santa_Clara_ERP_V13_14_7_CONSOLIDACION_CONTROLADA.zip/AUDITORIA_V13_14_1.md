# Auditoría inicial Santa Clara ERP V13.14.1

## Verificaciones ejecutadas
- Compilación de app.py: correcta.
- Rutas Flask declaradas en el código: 285; sin rutas URL duplicadas en el análisis estático.
- Plantillas Jinja: 169; verificación de compilación con los tres filtros personalizados declarados en app.py.
- requirements.txt: eliminada una declaración duplicada de PyMuPDF==1.26.4.

## Hallazgos que requieren pruebas funcionales antes de modificar
- El Comparativo Contable verifica balance Debe/Haber, pero ello por sí solo no garantiza imputación contable correcta.
- La asociación de asientos debe probarse con ventas, compras, documentos anulados, asientos agrupados y monedas extranjeras.
- No se ha probado emisión/cancelación SIFEN contra el servicio oficial ni se ha conectado a la base de datos real.
- La lógica de caja, stock, internación, compras, ventas, permisos y liquidaciones requiere pruebas transaccionales con una copia anonimizada de la base de datos.

## Política de cambios
No se alteraron app.py, plantillas, datos, configuración SIFEN ni operaciones. La única corrección aplicada es la eliminación de un requisito repetido, sin cambio de versión de dependencia.

## Estado
Esta es una auditoría estática inicial y una corrección de empaquetado; NO constituye una certificación de ausencia de errores operativos. No desplegar sin pruebas de regresión.
