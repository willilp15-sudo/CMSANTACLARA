# Santa Clara ERP V13.10.50

- QR documental visible en la vista/impresión HTML de recibos.
- QR estable por tipo + referencia: reimpresiones reutilizan el mismo código.
- Estado de validación actualizado a VALIDO/ANULADO.
- PDF conserva QR documental.
- Se mantiene la conversión del importe en letras basada en el importe real del recibo.
- SIFEN/KuDE/CDC/XML/firma/QR fiscal no fueron modificados.
