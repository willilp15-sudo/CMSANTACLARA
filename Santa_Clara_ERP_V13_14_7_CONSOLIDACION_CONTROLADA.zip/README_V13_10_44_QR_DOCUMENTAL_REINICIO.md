# Santa Clara ERP V13.10.44 — QR documental + reinicio operativo

Base exacta: V13.10.43 Santa Clara Asistencia Móvil suministrada por el usuario.

## QR documental
- Registro único de documentos internos emitidos por el ERP.
- QR en PDFs internos principales: liquidaciones de salarios, liquidaciones médicas/cierre de consultorio, Laboratorio LACED, recibos, informes generales, contabilidad, arqueos de caja, visaciones, transferencias de depósito y CxC/CxP.
- El QR abre `/validar-documento/<token>` y muestra tipo, código, referencia, fecha/hora y estado del documento.
- Los documentos fiscales SIFEN/KuDE/NC/ND conservan su QR y lógica fiscal existentes; no se agrega el QR interno sobre ellos.

## Reinicio operativo para migración
- Administración > Reinicio / Base limpia.
- Requiere administrador, frase `BORRAR BASE` y contraseña.
- Crea backup antes de borrar datos operativos.
- Preserva configuración SIFEN, puntos de expedición, actividades económicas, correlativos, eventos, configuración institucional y seguridad/usuarios.
- No elimina `/var/data` ni sustituye la base físicamente.

## Instalación
No reemplazar la base de datos ni `/var/data`.
