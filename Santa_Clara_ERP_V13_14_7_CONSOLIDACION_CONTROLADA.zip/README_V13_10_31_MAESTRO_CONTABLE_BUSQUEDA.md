# Santa Clara ERP V13.10.31

Base: V13.10.30 suministrada por el usuario.

## Cambios
- Maestro de Contabilidad consolidado y ordenado por Contabilidad General, IVA, Retenciones, Marangatu/DNIT, Impuestos, Cierre Contable e Informes/Auditoría.
- Menú lateral: un único acceso a Maestro de Contabilidad para evitar accesos contables repetidos.
- Compras: búsqueda por ID, código interno CMP-000001, comprobante, RUC, proveedor, estado o fecha.
- Compras: acceso directo a Ver, Modificar y Eliminar con la reversión controlada ya existente.
- Ventas: buscador de registros por ID, VTA-000001, factura, CDC, RUC/CI, cliente, estado o fecha.
- Nuevos accesos de Asientos Contables, Centros de Costos, Cierre y Auditoría.
- No se modifica el núcleo SIFEN.
- No se reemplaza la base de datos persistente.
