# Santa Clara ERP V13.10.47 — Códigos de clientes/proveedores + Gasparini

- Agrega `codigo_registro` al maestro `terceros` mediante migración aditiva.
- Asigna códigos automáticos a registros existentes: `CLI-######` y `PRO-######`.
- Permite indicar/editar el código manualmente en Clientes y Proveedores.
- Los códigos son únicos (sin distinguir mayúsculas/minúsculas).
- La importación detallada/CxC/CxP reconoce códigos de tercero provenientes de archivos con encabezados Gasparini/Excel: Código Cliente, Cod Cliente, ID Cliente, Código Proveedor, Cod Proveedor, ID Proveedor, Código Tercero y variantes normalizadas.
- Si el archivo trae código, se usa para localizar o actualizar el maestro sin duplicarlo. Si no trae código, se genera automáticamente.
- La plantilla de importación detallada incorpora la columna `Codigo Tercero`.
- No modifica SIFEN, CDC, XML, firma, QR fiscal ni configuración fiscal.
