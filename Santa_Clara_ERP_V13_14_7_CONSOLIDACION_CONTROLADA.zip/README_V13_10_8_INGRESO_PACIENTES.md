# Santa Clara ERP V13.10.8 — Ingreso de Pacientes Unificado

## Objetivo
Reemplazar en la operación diaria el concepto visible de "Admisión / Internación" por un único **Ingreso de Pacientes** para Internación y Cirugía / Quirófano, conservando las tablas, IDs, cuentas e historial existentes para compatibilidad.

## Cambios
- Nueva ruta visible `/ingreso-pacientes`; `/admisiones` se conserva como alias técnico compatible.
- Formulario único inspirado en el modelo suministrado: número de ingreso automático, paciente, fecha/hora, tipo de ingreso, seguro, carnet, médico, sala/cama, diagnóstico, observaciones, responsable/acompañante y usuario receptor.
- Tipo de ingreso operativo: Internación o Cirugía / Quirófano.
- Facturar a tercero puede definirse desde el ingreso y se usa como receptor predeterminado al facturar, manteniendo separado el paciente real.
- Quirófano no genera una segunda admisión: continúa sobre el mismo ID/cuenta del paciente.
- Menú: Atención > Ingreso y hospitalización > Ingreso de Pacientes / Salas y Camas / Enfermería.
- Migración SQLite idempotente: agrega únicamente campos nuevos a `admisiones`; no elimina ni renombra columnas existentes.

## Seguridad de actualización
No reemplazar la base de datos ni `/var/data`. No se modificó el motor SIFEN, firma, QR, CDC, transmisión, cancelación, NCE/NDE ni configuración fiscal.

## Archivos modificados respecto de V13.10.7
- `app.py`
- `templates/base.html`
- `templates/hospital_admissions.html`
- `templates/hospital_admission_edit.html`
