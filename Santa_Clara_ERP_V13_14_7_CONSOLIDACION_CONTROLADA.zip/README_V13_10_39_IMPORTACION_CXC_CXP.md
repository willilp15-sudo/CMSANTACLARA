# V13.10.39 — Importación histórica CxC/CxP

Base: V13.10.38.

- Importa estados de Cuentas por Cobrar y Cuentas por Pagar Gasparini sin cabecera.
- Vincula tercero y documento/factura.
- Conserva fecha, vencimiento, moneda, importe, saldo y datos fuente.
- Actualiza por tercero + documento para evitar duplicados.
- No afecta stock.
- No genera asientos contables históricos.
- No modifica SIFEN.
