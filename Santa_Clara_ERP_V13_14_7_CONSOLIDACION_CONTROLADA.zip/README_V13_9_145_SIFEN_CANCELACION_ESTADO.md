# V13.9.145 — Cancelación SIFEN y preservación de estado DTE

- Preserva APROBADO una vez que SIFEN aprobó el DTE.
- Una consulta de lote histórico ya no puede degradar APROBADO a RESPUESTA_RECIBIDA/0301/0365.
- La cancelación detecta aprobación histórica en sifen_eventos si versiones anteriores sobrescribieron estado_sifen.
- Si una versión anterior anuló localmente por error un DTE aprobado, el botón puede registrar todavía la cancelación real ante SIFEN.
- Sólo 0600 marca CANCELADO.
- Si el evento es rechazado, restaura APROBADO y revierte una ANULADA local accidental a EMITIDA.
- No modifica el generador DE/QR/IdCSC ya aprobado por SIFEN.
