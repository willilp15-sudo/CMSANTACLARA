V13.9.146
- Recupera aprobación histórica por código SIFEN 0260 + CDC aunque estado textual haya sido sobrescrito por 0365.
- Fuerza que DTE previamente aprobado use Evento de Cancelación y no anulación interna.
- No modifica QR/CSC/IdCSC ni generación de FE.
