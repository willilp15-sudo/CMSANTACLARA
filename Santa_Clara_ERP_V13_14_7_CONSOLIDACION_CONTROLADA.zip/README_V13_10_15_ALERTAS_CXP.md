# V13.10.15 - Alertas semanales de Cuentas a Pagar

- Agrega al Centro de Operaciones una lista automática de cuentas vencidas y cuentas que vencen en la semana actual.
- Las cuentas vencidas continúan visibles semana tras semana mientras exista saldo pendiente.
- Los pagos parciales conservan el documento en la alerta por el saldo restante.
- Cuando el saldo llega a cero y CxP queda PAGADO, desaparece automáticamente del recordatorio.
- La alerta solo se muestra a usuarios con permiso VER en COMPRAS o FINANZAS.
- Incluye acceso directo al pago del proveedor.
- No modifica FE/NCE/NDE, SIFEN, XML, firma, QR, correlatividad, cancelación ni stock.
- Versión acumulativa sobre V13.10.14.
