# Santa Clara ERP V13.10.42 — Tarifarios de Seguros
Base: V13.10.41 instalada por el usuario.

## Incorporado
- Administración > Tarifarios de Seguros.
- Listas por aseguradora/convenio, moneda y vigencia desde/hasta.
- Precios diferenciados para productos/medicamentos/descartables, servicios/procedimientos y consultas/especialidades.
- Histórico por tarifarios: no se sobrescriben prestaciones ya registradas.
- Activación/desactivación de ítems y ajuste porcentual masivo.
- En cuentas de pacientes con seguro, productos y servicios toman el precio vigente del tarifario.
- En agendamiento por seguro, la consulta toma el precio vigente de la especialidad si existe.
- Sin tarifa específica, conserva el precio particular vigente como respaldo.

## Seguridad
- No reemplazar la base de datos ni /var/data.
- SIFEN no fue modificado.
