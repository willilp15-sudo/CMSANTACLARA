# Santa Clara ERP V13.12.0 — Consolidación Integral / Contabilidad Paraguay

Base: V13.11.4 Nómina y Pagos Trazables.

## Cambios principales
- Nuevo Control Integral Contable en `/contabilidad/control`.
- Indicadores de ventas, compras, CxC y CxP.
- Controles de documentos sin contabilizar y asientos desbalanceados.
- Control de documentos SIFEN pendientes/no aprobados.
- Accesos directos a Diario, Mayor, Balance, estados financieros, RG90, IVA, conciliación fiscal, bancos y centros de costos.
- Menú de Contabilidad simplificado con acceso al Control Integral.
- Se corrige el orden del `app.run`: ahora queda al final de `app.py`, evitando que las rutas agregadas en versiones posteriores queden sin registrar al ejecutar `python app.py`.
- No se modifica ni reemplaza la base de datos.
- No se altera el núcleo de emisión/cancelación SIFEN existente.

## Archivos modificados
- app.py
- templates/base.html
- templates/accounting.html
- static/app.css

## Archivo nuevo
- templates/accounting_control_center.html

## Instalación sobre V13.11.4
Reemplazar los cuatro archivos modificados y agregar la plantilla nueva. No reemplazar la base de datos, certificados, claves, CSC ni XML históricos.

## Nota de cumplimiento
El módulo organiza controles contables y fiscales del ERP, pero las obligaciones concretas deben parametrizarse según el RUC y validarse contra las disposiciones vigentes de DNIT y el profesional contable responsable.
