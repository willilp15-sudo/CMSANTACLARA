# V13.10.51 - Validación QR pública

Base: V13.10.50 aportada por el usuario.

Corrección:
- `validar_documento_publico` se excluye del requisito de sesión en ambos controles globales `before_request`.
- `documento_qr_svg` también queda público para permitir representar el QR sin sesión cuando corresponda.
- La validación sigue siendo de solo lectura; no se habilita acceso a módulos internos.
- No se modifica SIFEN, CDC, XML, firma, KuDE ni QR fiscal.

Actualización desde V13.10.50: reemplazar únicamente `app.py`.
