# V13.14.3 — Atención clínica

Se revisó y reforzó la ruta `/mis-pacientes`: manejo de sesión ausente, fecha inválida, cierre de conexión garantizado y errores SQLite registrados sin mostrar datos sensibles al usuario. Se agregó aviso de consulta no disponible (HTTP 503) en vez de excepción 500 para fallas de base de datos.

No se modificaron los módulos de SIFEN, las tablas ni los registros existentes. La ruta `/operacion-clinica` conserva su implementación original.

**Limitación:** el error HTTP 500 reportado no incluye traceback, por lo que no es posible asegurar que esta actualización corrija su causa real. Se requiere prueba con base de datos y sesión reales antes de producción.

Para actualizar en GitHub/Render, sustituir `app.py` y `templates/doctor_patients_v12.html` y desplegar. Hacer respaldo y probar primero en staging.
