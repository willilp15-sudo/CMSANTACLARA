# Santa Clara ERP V13.11.0 — Consolidación y Estabilización

Base: V13.10.55 consolidada suministrada por el usuario.

## Cambios seguros
- Nuevo Centro de Maestros único (`/maestros`) que centraliza los maestros existentes sin crear tablas paralelas.
- Menú Maestros simplificado a un único acceso central.
- Reutiliza clientes/pacientes, proveedores, funcionarios, médicos, productos/servicios, depósitos, seguros/tarifarios, bancos/POS, monedas, contabilidad y seguridad existentes.
- Corrección de una colisión real de funciones `_norm_header`: Retenciones/Marangatu ahora usa `_norm_header_retenciones`, evitando que otro importador sobrescriba silenciosamente su normalizador.
- Ajustes de densidad visual para tablas/formularios y tarjetas del Centro de Maestros.

## Compatibilidad
- No se elimina ni renombra ninguna tabla existente.
- No se modifica la base de datos del usuario.
- No se eliminan rutas operativas existentes.
- SIFEN permanece fuera de esta intervención: no se modifica emisión, CDC, XML, firma, CSC, QR fiscal, KuDE ni cancelación.

## Validaciones realizadas
- `app.py` compila con Python.
- 163 plantillas Jinja analizadas sin errores de sintaxis.
- No quedan funciones top-level duplicadas en `app.py`.
- No se detectaron rutas Flask literales duplicadas.
