"""Auditoría estática no destructiva de rutas y enlaces HTML."""
from pathlib import Path
import re, ast
root=Path(__file__).resolve().parent
source=(root/'app.py').read_text(encoding='utf-8')
tree=ast.parse(source)
routes=set()
for node in ast.walk(tree):
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for d in node.decorator_list:
            if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr in ('route','get','post') and d.args and isinstance(d.args[0],ast.Constant) and isinstance(d.args[0].value,str):
                routes.add(d.args[0].value)
links={}
for path in (root/'templates').rglob('*.html'):
    txt=path.read_text(encoding='utf-8',errors='replace')
    for link in re.findall(r'href=["\'](/[^"\'#?]*)',txt):
        if '{{' in link or '<' in link or link.startswith('/static/') or link in routes:continue
        links.setdefault(link,[]).append(str(path.relative_to(root)))
print('Rutas literales:',len(routes))
print('Enlaces literales sin coincidencia exacta (pueden ser rutas parametrizadas):',len(links))
for link,paths in sorted(links.items()):print(link,'=>',', '.join(paths[:3]))
