# Santa Clara ERP V13.10.26 — Transferencias, responsables, firmas y PDF

Base: V13.10.25.

## Cambios
- Transferencias entre depósitos: responsable que entrega y responsable que recibe (funcionarios activos).
- Historial muestra ambos responsables.
- Documento PDF institucional por transferencia, con opción de abrir para imprimir o descargar.
- Firma por funcionario en RR.HH.: PNG, JPG, JPEG o PDF.
- Los PDF de firma se convierten a una imagen interna para poder insertarlos en documentos PDF; el original se conserva en almacenamiento persistente.
- Las firmas se guardan bajo DATA_DIR/rrhh/firmas (en Render: /var/data/rrhh/firmas).
- Transferencias antiguas permanecen válidas; sus responsables quedan vacíos si fueron creadas antes de esta versión.

## Archivos modificados
- app.py
- requirements.txt
- templates/stock_transfers.html
- templates/rrhh_employees.html
- templates/rrhh_employee_edit.html

## Seguridad funcional
No se modifica el motor SIFEN, FE/NCE/NDE, CDC/QR, cancelaciones, Libros IVA, Comparativo Contable ni importadores Gasparini.
