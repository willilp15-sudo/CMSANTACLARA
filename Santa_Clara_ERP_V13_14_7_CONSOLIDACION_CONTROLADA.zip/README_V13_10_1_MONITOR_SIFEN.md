# V13.10.1 – Monitor SIFEN operativo
- Base: V13.10.0 / núcleo fiscal V13.9.149.
- No cambia generación XML FE, firma, QR, CSC/IdCSC, envío individual, consulta ni cancelación.
- Monitor operativo oculta estados finales (APROBADO/ACEPTADO/CANCELADO/etc.).
- Historial procesado conserva trazabilidad sin borrar documentos fiscales.
- Selección múltiple de Facturas Electrónicas y envío masivo reutilizando `_sifen_emitir_factura_automatico()`.
- Protección backend: estados finales jamás se reenvían aunque se manipule el formulario.
- NC/NDE excluidas del envío masivo mientras no exista transmisor real completo.
