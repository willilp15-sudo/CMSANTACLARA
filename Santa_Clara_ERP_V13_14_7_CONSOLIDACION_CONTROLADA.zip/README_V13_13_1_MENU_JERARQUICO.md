# Santa Clara ERP V13.13.1 - Menú jerárquico

Implementa navegación visual de tres niveles: BOTÓN PRINCIPAL > GRUPO > SUBGRUPO.

Objetivo: reducir duplicación visual sin borrar rutas ni procesos históricos que aún son dependencias internas.

Archivos modificados:
- templates/base.html
- static/app.css

No reemplazar base de datos, certificados SIFEN, CSC, XML ni variables de entorno.
