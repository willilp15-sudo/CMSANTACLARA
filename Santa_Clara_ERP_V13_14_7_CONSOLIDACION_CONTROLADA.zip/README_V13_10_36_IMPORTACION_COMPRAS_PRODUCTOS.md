# Santa Clara ERP V13.10.36 — Importación detallada de compras

Base: V13.10.35 CONSOLIDADA DESDE V13.10.33.

## Alcance de esta versión
- Importación del CSV detallado de compras Santa Clara/Gasparini sin cabecera.
- Agrupa las líneas por ID de compra de origen para reconstruir cada factura con todos sus productos.
- Registra proveedor, comprobante, fecha, timbrado, producto, cantidad, costo unitario, IVA y clasificación.
- Conserva metadatos de origen por ítem: código fuente, lote, vencimiento del producto, marca/laboratorio, unidad, ID de compra, ID de ítem, clasificación contable de origen, usuario de origen y fila bruta para auditoría.
- Los productos nuevos se crean en el maestro; medicamentos/farmacia activan control de lote y vencimiento cuando corresponde.
- La opción "Afectar stock" permanece desmarcada por defecto para importaciones históricas.
- Si el RUC no es consistente entre las líneas de una compra de origen, no se inventa: el proveedor se identifica por nombre y el registro bruto queda preservado.

## Protección SIFEN
No se modificó ninguna función SIFEN, XML, CDC, QR, XMLDSig/firma, CSC/IdCSC, envío, consulta, cancelación, NCE/NDE o KUDE.

## Archivos modificados respecto a V13.10.35
- app.py
- templates/base.html
- templates/transaction_exchange.html
- templates/purchase_detail.html

No reemplazar la base de datos ni /var/data.
