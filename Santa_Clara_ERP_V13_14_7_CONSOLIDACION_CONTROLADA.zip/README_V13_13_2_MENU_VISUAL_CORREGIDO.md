# Santa Clara ERP V13.13.2 — Menú visual corregido

Corrección acumulativa sobre V13.13.1.

- Contraste explícito de textos del menú desplegable.
- Fondo sólido y legible en tema claro y oscuro.
- Menú principal más compacto para resoluciones de escritorio.
- Mega-menús con scroll interno cuando exceden la altura disponible.
- Responsive reorganizado para notebook/tablet/celular.
- No modifica base de datos, SIFEN ni lógica operativa.

Desde V13.13.1 basta reemplazar `static/app.css`.
Si la instalación no tiene sincronizada V13.13.0/1, reemplazar además `templates/base.html` y `app.py` y verificar `templates/system_map.html`.
