# Santa Clara ERP V13.10.20 — Importación CSV Gasparini Compras

Base: V13.10.19 Libros Compras/Ventas entregada por el usuario.

## Corrección
- Reconoce el CSV real de Gasparini `COMPRAS 2026.csv` sin fila de encabezados.
- Formato verificado: 1.080 filas, 16 columnas, codificación Windows-1252/CP1252, delimitador coma.
- Mapea RUC, DV, proveedor, timbrado, factura, fecha, base/IVA 10%, base/IVA 5% y exentas.
- Conserva el número de factura como texto con sus ceros y guiones.
- Crea líneas sintéticas de tipo SERVICIO únicamente para representar el desglose tributario; no crea stock físico.
- Conserva exactamente los importes fiscales del archivo fuente, evitando diferencias por redondeo al recalcular IVA incluido.
- Como este Libro IVA no informa de forma verificable el saldo pendiente, se importa con saldo 0 y no crea CxP históricas ficticias.
- No modifica SIFEN ni su motor de emisión/firma/cancelación.

## Prueba con archivo real
Archivo: COMPRAS 2026.csv
- 1.080 filas fuente leídas.
- 16 columnas estables por fila.
- CP1252 detectado correctamente.
- 1.080 claves únicas factura + RUC/DV.
- Primera factura detectada: 001-001-0000247.
- RUC: 7736572-0.
- Proveedor: ALEXANDER ANTONIO OCHOA CHAVEZ.
- Timbrado: 14810564.
- Fecha: 01/04/2026.
- Base 10%: 13.585.455.
- IVA 10%: 1.358.545.
- Total fuente: 14.944.000.

## Archivo modificado
- app.py
