# V13.10.35 - Corrección RR.HH. Novedades / Anticipos

Base: V13.10.34.

- Corrige HTTP 500 al abrir `/rrhh/novedades`.
- La ruta ahora carga las cuentas bancarias activas requeridas por `rrhh_events.html`.
- Mantiene registro de anticipos/préstamos integrado con Tesorería y Contabilidad.
- No modifica SIFEN ni la base de datos existente.

Actualización desde V13.10.34: reemplazar únicamente `app.py`.
