# Santa Clara ERP V13.10.11 — Menú dinámico por permisos

- Basada en V13.10.10 e incluye V13.10.9.
- El menú principal y sus subopciones se renderizan según permisos efectivos del usuario.
- Usuarios multirrol ven la unión de opciones permitidas por sus roles.
- Módulos sin ninguna opción autorizada no se muestran.
- Administrador conserva acceso total mediante el mecanismo existente de SUPERADMIN.
- Los controles backend existentes no se eliminan; ocultar el menú es una capa adicional de interfaz.
- No se modifica el motor SIFEN ni la base de datos.
