# Santa Clara ERP V13.11.4 — Nómina y Pagos

Actualización acumulativa sobre V13.11.3.

## RR.HH. / Nómina
- Flujo formal: BORRADOR → APROBADA → PAGADA.
- Aprobación genera asiento de devengamiento de nómina y conserva centro de costo.
- Anulación exige motivo, usuario y fecha; no elimina la liquidación.
- Una liquidación PAGADA no puede anularse hasta anular primero su pago.
- Se impide recalcular liquidaciones ya aprobadas/pagadas/anuladas.

## Pagos de Nómina
- Nueva pantalla RR.HH. → Pagos de Nómina.
- Selección individual de funcionarios.
- Para cada funcionario se puede elegir medio y cuenta bancaria de origen.
- Efectivo utiliza la cuenta de caja configurada; banco/transferencia exige una cuenta bancaria activa con cuenta contable vinculada.
- El importe financiero es el NETO A COBRAR, no el costo empresa.
- Cada pago genera egreso de Tesorería y asiento contable.
- Prevención de doble pago mediante estado APROBADA/PAGADA.
- Anulación del pago genera asiento reverso y contramovimiento financiero, conserva auditoría y devuelve la liquidación a APROBADA.

## Base de datos
La migración es incremental. No borrar ni reemplazar la base de datos existente.
