# Santa Clara ERP V13.10.25 — Productos, cuentas contables y depósitos

Base: V13.10.24 LIBROS IVA + COMPARATIVO INTEGRADO.

## Cambios aditivos
- Maestro de productos: clasificación, IVA 5/10/exento, cuenta de inventario, cuenta de costo/gasto, cuenta de ingreso y control explícito de stock.
- Servicios Sanatoriales pueden quedar sin control de stock.
- Maestro de depósitos con Farmacia Interna como depósito principal.
- Transferencias entre depósitos sin alterar el stock total del producto.
- Inventario por depósito con costo y valorización.
- El stock histórico existente permanece en `productos.stock`; Farmacia Interna se calcula como stock total menos lo distribuido a depósitos secundarios, por lo que no se duplica inventario al instalar.

## No modificado
Motor SIFEN, FE/NCE/NDE, firma, CDC/QR, cancelaciones, correlatividad, libros IVA, comparativo contable e importadores Gasparini.
