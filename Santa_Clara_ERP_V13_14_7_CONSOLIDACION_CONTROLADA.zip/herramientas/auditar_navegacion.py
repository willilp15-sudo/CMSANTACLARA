#!/usr/bin/env python3
"""Auditoría estática de rutas y enlaces; no accede ni modifica bases de datos."""
import ast, json, re
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'app.py').read_text(encoding='utf-8')
tree=ast.parse(source)
routes=defaultdict(list); endpoints={}
for node in tree.body:
    if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)): continue
    for d in node.decorator_list:
        if not isinstance(d,ast.Call) or not isinstance(d.func,ast.Attribute) or d.func.attr not in ('get','post','route'):continue
        if d.args and isinstance(d.args[0],ast.Constant) and isinstance(d.args[0].value,str):
            path=d.args[0].value
            routes[path].append(node.name)
            endpoints[node.name]=path
bad=[]; repeats=defaultdict(list); seen=0
for template in (ROOT/'templates').rglob('*.html'):
    data=template.read_text(encoding='utf-8',errors='replace')
    for match in re.finditer(r'href=["\'](/[^"\'#?]+)',data):
        path=match.group(1);seen+=1;repeats[path].append(str(template.relative_to(ROOT)))
        if path not in routes and not path.startswith(('/static/','/api/')) and '<' not in path and '{' not in path:bad.append({'plantilla':str(template.relative_to(ROOT)),'ruta':path})
    for match in re.finditer(r'url_for\(["\']([^"\']+)',data):
        endpoint=match.group(1)
        if endpoint not in endpoints and endpoint!='static':bad.append({'plantilla':str(template.relative_to(ROOT)),'endpoint':endpoint})
report={'rutas':len(routes),'enlaces_directos':seen,'rutas_duplicadas':{p:v for p,v in routes.items() if len(v)>1},'enlaces_a_revisar':bad,'destinos_en_4_o_mas_plantillas':{p:sorted(set(v)) for p,v in repeats.items() if len(set(v))>=4}}
print(json.dumps(report,ensure_ascii=False,indent=2))
