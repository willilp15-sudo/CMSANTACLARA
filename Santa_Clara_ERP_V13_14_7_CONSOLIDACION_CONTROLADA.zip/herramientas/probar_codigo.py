#!/usr/bin/env python3
"""Pruebas estáticas no destructivas, no requieren claves ni base de datos."""
from pathlib import Path
import ast,zipfile,sys
from jinja2 import Environment
root=Path(__file__).resolve().parents[1]
pyfiles=list(root.rglob('*.py'))
for f in pyfiles:ast.parse(f.read_text(encoding='utf-8-sig'),filename=str(f))
html=list((root/'templates').rglob('*.html'))
for f in html:Environment().parse(f.read_text(encoding='utf-8-sig'))
print(f'OK: sintaxis de {len(pyfiles)} archivos Python y parseo de {len(html)} plantillas Jinja')
