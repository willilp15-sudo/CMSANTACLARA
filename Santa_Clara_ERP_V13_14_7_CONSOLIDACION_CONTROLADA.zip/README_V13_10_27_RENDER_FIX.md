# Santa Clara ERP V13.10.27 — Render Fix

Corrección puntual sobre V13.10.26.

- Corregido el decorador de la ruta `/farmacia/inventario-depositos` que tenía dos comillas simples antes de `@app.get` y provocaba `TypeError: unsupported operand type(s) for @: 'str' and 'function'` durante el arranque en Render.
- Revisados otros decoradores `@app.*` para detectar el mismo patrón.
- No se modificó la base de datos ni `/var/data`.
- No se modificó el núcleo SIFEN ni las funciones de facturación.
