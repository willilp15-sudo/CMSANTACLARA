# V13.14.4 – Centro clínico autónomo

Se aisló la plantilla de /operacion-clinica del layout global para reducir fallos de renderizado. No se modificó SIFEN ni la base de datos. No se puede asegurar que solucione el 500 sin traceback de producción.
