# Santa Clara ERP V13.10.55

Base: V13.10.53 suministrada por el usuario.

Cambios consolidados:
- Código interno Gasparini para clientes/proveedores, preservando ceros a la izquierda y permitiendo el mismo código en maestros distintos.
- QR documental HTML embebido como data URI: visible antes de imprimir y no depende de una segunda petición autenticada.
- Los PDF internos continúan usando QR embebido mediante ReportLab.
- Recibo: elimina “Entregué conforme”; deja solo “Recibí conforme”.
- Recibo: usa automáticamente la firma del funcionario vinculado al usuario que registró el cobro, si tiene firma cargada en RR.HH.
- PDF del recibo incluye la misma firma/responsable.
- No se modifica el núcleo SIFEN/CDC/XML/firma/QR fiscal/cancelación.

Actualización desde V13.10.53: reemplazar app.py y templates/receipt.html. No reemplazar la base de datos ni /var/data.
