# Santa Clara ERP V13.10.37

Corrección puntual del importador detallado de compras de V13.10.36.

- Corrige el código de producto del CSV fuente: usa la columna individual de artículo (36, respaldo 38) en vez de la columna 14 repetida.
- Al reimportar una compra importada previamente, reconstruye sus ítems con los productos correctos usando la lógica existente de actualización.
- No modifica el núcleo SIFEN, XML, CDC, QR, firma, CSC, envío, consulta, cancelación, NCE/NDE ni KUDE.
- No requiere reemplazar la base de datos.
