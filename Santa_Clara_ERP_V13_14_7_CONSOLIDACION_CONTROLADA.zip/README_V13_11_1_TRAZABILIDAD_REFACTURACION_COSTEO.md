# Santa Clara ERP V13.11.1 — Trazabilidad, refacturación y costeo

## Correcciones principales

1. Una factura cancelada ya no elimina ni inutiliza la cuenta clínica de Internación/Urgencia.
2. Los cargos de la cuenta quedan vinculados a la venta que los facturó (`factura_venta_id`).
3. Al cancelarse correctamente una factura, solo los cargos de esa factura vuelven a `facturado=0`.
4. La remisión vuelve a estado `PENDIENTE` y puede ser facturada nuevamente con un nuevo correlativo.
5. Se conserva el vínculo entre factura anterior y nueva factura (`factura_anterior_id`) para auditoría.
6. La cancelación/refacturación de una cuenta clínica NO devuelve medicamentos al stock. El consumo físico ocurrió en Farmacia/Internación y solo una devolución/estorno real debe reponer existencias.

## Costeo

La revisión de V13.11.0 detectó dos problemas importantes:

- Las compras sustituían `productos.costo_pyg` por el costo de la última compra. V13.11.1 utiliza costo promedio ponderado en nuevas entradas de compras normales, edición/reprocesamiento e importación masiva.
- Los cargos clínicos de medicamentos no conservaban el costo histórico y Caja Central generaba `venta_items.costo_pyg=0`. Esto hacía que la rentabilidad de Internación/Urgencia apareciera con costo cero.

V13.11.1 guarda el costo del medicamento/insumo en el momento del consumo dentro de `cargos_paciente.costo_pyg`, lo traslada a `venta_items.costo_pyg` al facturar y registra el costo contable al emitir la factura de la cuenta clínica.

## Migración automática

Al iniciar el sistema se agregan, si no existen:

- `cargos_paciente.costo_pyg`
- `cargos_paciente.factura_venta_id`
- `ventas.origen_admision_id`
- `ventas.origen_remision_id`
- `ventas.factura_anterior_id`
- `remisiones_internas.venta_id`

No se modifica el núcleo de emisión, firma, CDC/QR ni cancelación SIFEN.

## Nota sobre datos históricos

Los cargos creados antes de V13.11.1 no tenían una fotografía del costo al momento del consumo. Por ello, el sistema no puede reconstruir con exactitud ese costo histórico solo a partir del maestro actual. La mejora aplica correctamente a los nuevos consumos y facturaciones posteriores a la actualización.
