# Santa Clara ERP V13.14.7 — Consolidación controlada (fase 1)

## Alcance comprobado
- Se conserva la estructura y los módulos de V13.14.4.
- La pantalla autónoma del Centro Clínico usa `url_for` para los destinos cuya ruta y endpoint fueron verificados estáticamente.
- Se añaden herramientas de auditoría de navegación y pruebas de sintaxis/plantillas. Son de solo lectura.
- No se modifican tablas, migraciones, transacciones, SIFEN, certificados ni variables de entorno.

## Límites
Esta es una actualización **parcial y no destructiva**, NO una depuración funcional completa ni una certificación de producción. El error 500 no se ha reproducido con la base real. Enlaces compartidos no son necesariamente duplicados. No borrar registros o rutas sin verificar dependencias.

## Publicar de forma controlada en GitHub y Render
1. En GitHub, abrir `CMSANTACLARA` y confirmar que el código actual coincide con la versión que se desea sustituir.
2. En GitHub > Code > Download ZIP, guardar una copia de la versión actual. Guardar por separado un respaldo consistente de la base de datos y los archivos persistentes desde su alojamiento (el ZIP del código NO los incluye).
3. Verificar que Render > Settings > Branch corresponde a `main` y revisar si Auto Deploy está habilitado. Para controlar el momento de actualización, desactivar temporalmente Auto Deploy.
4. Subir **solo** `templates/operacion_clinica_autonoma.html`, `herramientas/auditar_navegacion.py`, `herramientas/probar_codigo.py` y este informe mediante GitHub > Add file > Upload files > Commit changes. No reemplazar `app.py` ni directorios de datos con este paquete.
5. Ejecutar localmente `python herramientas/probar_codigo.py` (si se dispone de Python) antes del despliegue.
6. En Render > Manual Deploy > Deploy latest commit. Esperar `Live`, abrir `/login` y `/operacion-clinica` con una cuenta autorizada, comprobar navegación y revisar logs por errores 500.
7. Si hay errores, en Render > Events / Deploys seleccionar el deploy anterior y hacer rollback (según opciones disponibles), o revertir el commit en GitHub y volver a desplegar. Los cambios en BD no se revierten automáticamente, por eso aquí no se incluyen migraciones.

**No copiar credenciales, certificados o la base de datos en GitHub.**
